const stripeApiKey = 'sk_test_51HkA23Kjnug6QegNGPKVoXb6FnjY4y1IfdmhH8h1Uubig8fWmY8rb99b1o9W20KL3OkTv4Cm3LGyjSZPLi3RWJSc00quHr2Fj3';
const apiUri = 'https://api.stripe.com/v1';



// Load all customers
let conclusion = document.getElementById('conclusion')
let limitAll = document.getElementById('limitAll');
let btnAll = document.getElementById('btnAll');

btnAll.addEventListener("click",  async function loadCustomers(event) {

  event.preventDefault();

  limitAllNum = Number(limitAll.value)

  const http = new XMLHttpRequest()
  http.open('GET', `${apiUri}/customers`, false);
  http.setRequestHeader('Authorization', 'Bearer ' + stripeApiKey);
  http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  await http.send();
  const customers = await JSON.parse(http.responseText).data;

  conclusion.innerHTML = JSON.stringify(customers);
  console.log(customers);
});



// Create a customer
let idCreate = document.getElementById('idCreate');
let emailCreate = document.getElementById('emailCreate')
let balanceCreate = document.getElementById('balanceCreate')
let descriptionCreate = document.getElementById('descriptionCreate')
let btnCreate = document.getElementById('btnCreate');

btnCreate.addEventListener("click",  async (event) => {

  event.preventDefault();

  console.log("work create");

  balanceCreateNum = Number(balanceCreate.value)

  const http = new XMLHttpRequest()
  http.open('POST', `${apiUri}/customers`, false);
  http.setRequestHeader('Authorization', 'Bearer ' + stripeApiKey);
  http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  const body = `description=${descriptionCreate.value}&email=${emailCreate.value}&id=${idCreate.value}&balance=${balanceCreateNum}`
  await http.send(body)
  const customers = await JSON.parse(http.responseText).data;
});



// Delete a customer
let idDelete = document.getElementById('idDelete');
let btnDelete = document.getElementById('btnDelete');

btnDelete.addEventListener("click",  async (event) => {

  event.preventDefault();

  console.log("work delete");

  balanceCreateNum = Number(balanceCreate.value)

  const http = new XMLHttpRequest()
  http.open('DELETE', `${apiUri}/customers/${idDelete.value}`, false);
  http.setRequestHeader('Authorization', 'Bearer ' + stripeApiKey);
  http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

  await http.send();
});



// Update a customer
let idUpdate = document.getElementById('idUpdate');
let emailUpdate = document.getElementById('emailUpdate')
let balanceUpdate = document.getElementById('balanceUpdate')
let descriptionUpdate = document.getElementById('descriptionUpdate')
let btnUpdate = document.getElementById('btnUpdate');

btnUpdate.addEventListener("click",  async (event) => {

  event.preventDefault();

  balanceUpdateNum = Number(balanceUpdate.value)

  console.log("work update");

  let request = ''
  request = `email` ? `${request}email=${emailUpdate.value}` : request,
  request = `description` ? `${request}&description=${descriptionUpdate.value}` : request,
  request = `balance` ? `${request}&balance=${balanceUpdateNum}` : request
  const http = new XMLHttpRequest()
  http.open('POST', `${apiUri}/customers/${idUpdate.value}`, false);
  http.setRequestHeader('Authorization', 'Bearer ' + stripeApiKey);
  http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
  console.log(request)
  await http.send(request);
});
